import { TRPCError } from '@trpc/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { USER_ROLE } from '@/lib/constant/roles';
import { createPasswordSchema } from '@/lib/password';
import { prisma } from '@/lib/prisma';
import {
  checkLoginRateLimit,
  extractClientIp,
  rateLimitToTRPCError,
  recordLoginSuccess,
} from '@/lib/rate-limit';
import { createSession, deleteSession, type SessionUser } from '@/lib/session';
import { createTRPCRouter, protectedProcedure, publicProcedure } from '../trpc';
import { USER_DETAIL_SELECT } from './_helpers/select';
import { isUserEmailUniqueConstraintError } from './_helpers/user-email-conflict';

const loginSchema = z.object({
  email: z.string().email('有効なメールアドレスを入力してください'),
  password: z.string().min(1, 'パスワードを入力してください'),
});

const registerSchema = z.object({
  name: z.string().min(1, '名前を入力してください'),
  email: z.string().email('有効なメールアドレスを入力してください'),
  password: createPasswordSchema('パスワードは8文字以上で入力してください'),
});

function handleUnexpectedError(context: string, error: unknown): never {
  console.error('[auth] unexpected error', { context, error });
  throw new TRPCError({
    code: 'INTERNAL_SERVER_ERROR',
    message: `${context}中にエラーが発生しました。時間をおいてお試しください。`,
    cause: error,
  });
}

export const authRouter = createTRPCRouter({
  login: publicProcedure.input(loginSchema).mutation(async ({ input, ctx }) => {
    const ip = extractClientIp(ctx.headers);

    // brute force 対策: 直近 15 分の失敗回数を email 単独 / email×IP / IP 単独の3軸で rate-limit。
    // checkLoginRateLimit は許可と同時に失敗行を先取りで記録する（成功時は recordLoginSuccess が削除）
    const limitResult = await checkLoginRateLimit(input.email, ip);
    if (!limitResult.allowed) {
      throw rateLimitToTRPCError(limitResult);
    }

    try {
      const user = await prisma.user.findUnique({
        where: { email: input.email },
      });

      if (!user?.password) {
        // 失敗は checkLoginRateLimit が先取りで記録済みのため、
        // ここでは追加記録しない
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'メールアドレスまたはパスワードが正しくありません',
        });
      }

      const isPasswordValid = await bcrypt.compare(input.password, user.password);

      if (!isPasswordValid) {
        // 失敗は checkLoginRateLimit が先取りで記録済みのため、
        // ここでは追加記録しない
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'メールアドレスまたはパスワードが正しくありません',
        });
      }

      if (!user.isActive) {
        // 無効判定はパスワード照合が通ったあとに行う。
        // 先に判定すると、正しいパスワードを知らなくても
        // 「無効化されたアカウントが存在する」ことを
        // 列挙できてしまうため。
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'このアカウントは無効化されています',
        });
      }

      const sessionUser: SessionUser = {
        id: user.id,
        email: user.email,
        role: user.role,
        version: user.sessionVersion,
      };

      // セッション発行の前に成功記録を確定させる。
      // 順序が逆だと、記録の失敗で 500 を返す一方で
      // 認証済みセッションだけが残るため。
      await recordLoginSuccess(input.email, ip);
      await createSession(sessionUser);

      return {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          avatar: user.avatar,
          role: user.role,
        },
      };
    } catch (error) {
      if (error instanceof TRPCError) throw error;
      handleUnexpectedError('ログイン処理', error);
    }
  }),

  register: publicProcedure.input(registerSchema).mutation(async ({ input }) => {
    try {
      const existing = await prisma.user.findUnique({
        where: { email: input.email },
      });

      if (existing) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'このメールアドレスは既に登録されています',
        });
      }

      const hashedPassword = await bcrypt.hash(input.password, 10);

      const user = await prisma.user.create({
        data: {
          email: input.email,
          name: input.name,
          password: hashedPassword,
          role: USER_ROLE.USER,
          isActive: true,
        },
      });

      const sessionUser: SessionUser = {
        id: user.id,
        email: user.email,
        role: user.role,
        version: user.sessionVersion,
      };

      await createSession(sessionUser);

      return {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          avatar: user.avatar,
          role: user.role,
        },
      };
    } catch (error) {
      if (error instanceof TRPCError) throw error;
      if (isUserEmailUniqueConstraintError(error)) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'このメールアドレスは既に登録されています',
        });
      }
      handleUnexpectedError('ユーザー登録処理', error);
    }
  }),

  logout: publicProcedure.mutation(async () => {
    await deleteSession();
    return { success: true };
  }),

  getSession: publicProcedure.query(async ({ ctx }) => {
    if (!ctx.session) {
      return null;
    }

    const user = await prisma.user.findUnique({
      where: { id: ctx.session.userId },
      select: {
        ...USER_DETAIL_SELECT,
        sessionVersion: true,
      },
    });

    if (!user?.isActive || user.sessionVersion !== ctx.session.version) {
      return null;
    }

    return {
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        role: user.role,
        isActive: user.isActive,
      },
    };
  }),

  getCurrentUser: protectedProcedure.query(async ({ ctx }) => {
    const user = await prisma.user.findUnique({
      where: { id: ctx.session.userId },
      select: {
        ...USER_DETAIL_SELECT,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!user) {
      throw new TRPCError({
        code: 'NOT_FOUND',
        message: 'ユーザーが見つかりません',
      });
    }

    if (!user.isActive) {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: 'このアカウントは無効化されています',
      });
    }

    return user;
  }),
});
